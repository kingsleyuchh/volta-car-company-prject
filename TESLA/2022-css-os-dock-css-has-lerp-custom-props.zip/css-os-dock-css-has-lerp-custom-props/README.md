# CSS OS Dock [CSS :has(), lerp custom props]

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/mdxggmO](https://codepen.io/jh3y/pen/mdxggmO).

